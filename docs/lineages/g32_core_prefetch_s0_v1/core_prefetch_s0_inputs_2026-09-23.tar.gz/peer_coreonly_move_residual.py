#!/usr/bin/env python3
"""Frozen hand-feature residual control for the four-type exact move pool."""
import argparse
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict, deque
from pathlib import Path

import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path('/tmp/herosim_peer_coreonly')
sys.path[:0] = [str(ROOT), '/tmp']
from scripts_cosim.important.generate_sampled_slate_snapshots import CosimOracleContext, snapshot_tasks, group_peer_exchange
from src.placement.network_fabric import route_links, is_core_link
from peer_coreonly_move_oracle import build_pool, candidate_lookup, load_lines, plan_key, trace_plan, sha, proxy

SEEDS = (9801, 9803, 9804, 9806)
MODELS = {
    'ridge': lambda: make_pipeline(SimpleImputer(strategy='constant', fill_value=0), StandardScaler(), Ridge(alpha=10.0)),
    'extratrees': lambda: ExtraTreesRegressor(n_estimators=300, min_samples_leaf=2, max_features=1.0, random_state=730, n_jobs=1),
}
CONTRACT = {
    'version': 'g32_core_prefetch_hand_control_v1', 'seeds': SEEDS, 'topology_split': 'leave_one_topology_out',
    'per_group_extra_evaluations': 16, 'baseline_evaluations': 2,
    'training_target': 'source_baseline_exact_rtt_minus_candidate_exact_rtt',
    'inference_rank': 'source_baseline_exact_rtt_minus_predicted_improvement, then placement lexicographic',
    'features': 'full candidate scalar costs/queue state; task/platform types; platform counts/load; peer 1/2/4-hop; per-core-link flow count/hold and synthetic wait; route-corrected physical proxy',
    'models': {'ridge': {'alpha': 10.0, 'standardized': True},
               'extratrees': {'n_estimators': 300, 'min_samples_leaf': 2, 'max_features': 1.0, 'random_state': 730}},
}


def summarize(prefix, vals, out):
    arr = np.asarray(vals, dtype=float)
    out[prefix+'_sum'] = float(arr.sum()) if len(arr) else 0.0
    out[prefix+'_mean'] = float(arr.mean()) if len(arr) else 0.0
    out[prefix+'_max'] = float(arr.max()) if len(arr) else 0.0
    out[prefix+'_std'] = float(arr.std()) if len(arr) else 0.0
    out[prefix+'_n'] = float(len(arr))


def route_stats(key, lookup, pairs, routes, bandwidth):
    flows = defaultdict(list)
    for a, b, payload in pairs:
        a, b, payload = int(a), int(b), float(payload)
        source = lookup[a][key[a]]['node_name']
        target = lookup[b][key[b]]['node_name']
        if source == target:
            continue
        for left, right in ((source, target), (target, source)):
            for link in route_links(routes, left, right):
                if is_core_link(link):
                    flows[link].append(payload / (bandwidth[link] * 1024 * 1024))
    counts = [len(values) for values in flows.values()]
    holds = [sum(values) for values in flows.values()]
    wait = sum(sum((len(values)-i-1)*duration for i,duration in enumerate(sorted(values,reverse=True)))
               for values in flows.values())
    result = {'synthetic_core_wait': float(wait),
              'core_overloaded_link_n': float(sum(n > 1 for n in counts))}
    summarize('core_link_flow_count', counts, result)
    summarize('core_link_hold', holds, result)
    for i, value in enumerate(sorted(holds, reverse=True)[:8]):
        result[f'core_link_hold_rank{i}'] = float(value)
    for i, value in enumerate(sorted(counts, reverse=True)[:8]):
        result[f'core_link_count_rank{i}'] = float(value)
    return result


def neighbor_balls(pairs):
    adj = [dict() for _ in range(32)]
    for a, b, payload in pairs:
        a, b = int(a), int(b)
        adj[a][b] = adj[a].get(b, 0.0) + float(payload)
        adj[b][a] = adj[b].get(a, 0.0) + float(payload)
    balls = {}
    for source in range(32):
        depth = {source: 0}
        queue = deque([source])
        while queue:
            i = queue.popleft()
            if depth[i] == 4:
                continue
            for j in sorted(adj[i]):
                if j not in depth:
                    depth[j] = depth[i]+1
                    queue.append(j)
        balls[source] = depth
    return adj, balls


def feature_row(key, source_key, source_rtt, tasks, lookup, pairs, adj, balls, source_tag, network, routes, bandwidth):
    out = {'source_rtt': source_rtt, 'source_is_hand': float(source_tag == 'hand')}
    changed = [i for i in range(32) if key[i] != source_key[i]]
    if not changed or len(changed) > 2:
        raise ValueError('candidate is not a single move or two-task swap')
    out['changed_n'] = float(len(changed))
    signature = [source_tag, str(len(changed))]
    scalar_fields = ('queue_length','current_task_remaining','cold_start_remaining','comm_remaining',
                     'execution_time','cold_start_time','network_latency','communications_time',
                     'queue_drain_seconds','energy','initialized')
    for field in scalar_fields:
        old_vals=[float(lookup[i][source_key[i]].get(field,0) or 0) for i in changed]
        new_vals=[float(lookup[i][key[i]].get(field,0) or 0) for i in changed]
        summarize('old_'+field,old_vals,out)
        summarize('new_'+field,new_vals,out)
        summarize('delta_'+field,[n-o for n,o in zip(new_vals,old_vals)],out)
    for task_type in ('cnn','dnn1','dnn2','rf'):
        out['task_type_'+task_type]=float(sum(tasks[i]['task_type']==task_type for i in changed))
    for platform_type in ('pynqFpga','rpiCpu','xavierCpu','xavierGpu'):
        out['source_platform_'+platform_type]=float(sum(lookup[i][source_key[i]]['platform_type']==platform_type for i in changed))
        out['target_platform_'+platform_type]=float(sum(lookup[i][key[i]]['platform_type']==platform_type for i in changed))
    out['same_node_move_n']=float(sum(source_key[i][0]==key[i][0] for i in changed))
    out['same_platform_type_move_n']=float(sum(lookup[i][source_key[i]]['platform_type']==lookup[i][key[i]]['platform_type'] for i in changed))
    for i in changed:
        signature.append(str(tasks[i]['task_type']))
        signature.append(str(lookup[i][source_key[i]]['platform_type']))
        signature.append(str(lookup[i][key[i]]['platform_type']))
    old_costs = []
    new_costs = []
    old_queue = []
    new_queue = []
    old_exec = []
    new_exec = []
    for i in changed:
        old, new = lookup[i][source_key[i]], lookup[i][key[i]]
        old_costs.append(sum(float(old.get(k, 0) or 0) for k in ('execution_time','communications_time','network_latency','queue_drain_seconds','cold_start_time')))
        new_costs.append(sum(float(new.get(k, 0) or 0) for k in ('execution_time','communications_time','network_latency','queue_drain_seconds','cold_start_time')))
        old_queue.append(float(old.get('queue_drain_seconds', 0) or 0))
        new_queue.append(float(new.get('queue_drain_seconds', 0) or 0))
        old_exec.append(float(old.get('execution_time', 0) or 0))
        new_exec.append(float(new.get('execution_time', 0) or 0))
    for prefix, vals in [('old_local',old_costs),('new_local',new_costs),('delta_local',[n-o for n,o in zip(new_costs,old_costs)]),
                         ('old_queue',old_queue),('new_queue',new_queue),('old_exec',old_exec),('new_exec',new_exec)]:
        summarize(prefix,vals,out)
    counts = defaultdict(int)
    exec_load = defaultdict(float)
    old_counts = defaultdict(int)
    for i, placement in enumerate(key):
        counts[placement] += 1
        exec_load[placement] += float(lookup[i][placement].get('execution_time',0) or 0)
        old_counts[source_key[i]] += 1
    summarize('platform_counts', list(counts.values()), out)
    summarize('platform_exec_load', list(exec_load.values()), out)
    out['platform_count_square_sum'] = float(sum(v*v for v in counts.values()))
    out['platform_exec_load_square_sum'] = float(sum(v*v for v in exec_load.values()))
    summarize('destination_occupancy',[counts[key[i]] for i in changed],out)
    summarize('source_occupancy',[old_counts[source_key[i]] for i in changed],out)
    peer_cut = []
    peer_same = []
    peer_changed = []
    old_peer_latency=[]
    new_peer_latency=[]
    for a,b,payload in pairs:
        a,b,payload = int(a),int(b),float(payload)
        cut = key[a][0] != key[b][0]
        (peer_cut if cut else peer_same).append(payload)
        if a in changed or b in changed:
            peer_changed.append(payload*(1 if cut else 0))
            def path_latency(plan):
                ca,cb=lookup[a][plan[a]],lookup[b][plan[b]]
                if plan[a][0]==plan[b][0]:
                    return 0.0
                na,nb=ca['node_name'],cb['node_name']
                ab,ba=network[na][nb],network[nb][na]
                return float(ab.get('latency',0) if isinstance(ab,dict) else ab)+float(ba.get('latency',0) if isinstance(ba,dict) else ba)
            old_peer_latency.append(path_latency(source_key)*payload)
            new_peer_latency.append(path_latency(key)*payload)
    summarize('peer_cut_payload',peer_cut,out)
    summarize('peer_same_payload',peer_same,out)
    summarize('peer_incident_cut_payload',peer_changed,out)
    summarize('old_peer_incident_weighted_latency',old_peer_latency,out)
    summarize('new_peer_incident_weighted_latency',new_peer_latency,out)
    summarize('delta_peer_incident_weighted_latency',[n-o for n,o in zip(new_peer_latency,old_peer_latency)],out)
    for hop in (1,2,4):
        ball_sizes=[];same_nodes=[];same_platforms=[];neighbor_exec=[];edge_weights=[];type_diversity=[]
        for i in changed:
            ball=[j for j,d in balls[i].items() if 1<=d<=hop]
            ball_sizes.append(len(ball))
            same_nodes.append(sum(key[j][0]==key[i][0] for j in ball))
            same_platforms.append(sum(key[j]==key[i] for j in ball))
            neighbor_exec.append(sum(float(lookup[j][key[j]].get('execution_time',0) or 0) for j in ball))
            edge_weights.append(sum(adj[i].get(j,0) for j in ball))
            type_diversity.append(len({str(tasks[j]['task_type']) for j in ball}))
        for prefix,vals in [('ball_n',ball_sizes),('same_node_n',same_nodes),('same_platform_n',same_platforms),
                            ('neighbor_exec',neighbor_exec),('incident_payload',edge_weights),('type_diversity',type_diversity)]:
            summarize(f'hop{hop}_{prefix}',vals,out)
    old_route=route_stats(source_key,lookup,pairs,routes,bandwidth)
    new_route=route_stats(key,lookup,pairs,routes,bandwidth)
    for name in sorted(set(old_route)|set(new_route)):
        old=float(old_route.get(name,0.0))
        new=float(new_route.get(name,0.0))
        out['old_route_'+name]=old
        out['new_route_'+name]=new
        out['delta_route_'+name]=new-old
    out['route_corrected_proxy']=proxy(key,lookup,pairs,network)+new_route['synthetic_core_wait']
    out['route_corrected_proxy_delta']=proxy(key,lookup,pairs,network)-proxy(source_key,lookup,pairs,network)+new_route['synthetic_core_wait']-old_route['synthetic_core_wait']
    return out, changed, tuple(signature)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--scores',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    scores=json.loads(args.scores.read_text())
    if len(scores['results']) != 64:
        raise ValueError('need all 64 exact groups')
    workload=json.loads(Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json').read_text())
    manifest=json.loads(Path('/tmp/fourtype-train-capture-manifest.json').read_text())
    grouped={(r['seed'],r['snapshot_id']):r for r in scores['results']}
    examples=[]
    for seed in SEEDS:
        paths=manifest['seeds'][str(seed)]['arms']
        snaps=load_lines(paths['hand']['paths']['-snapshots.jsonl']['path'])[:16]
        hand=load_lines(paths['hand']['paths']['-plans.jsonl']['path'])[:16]
        mpoff=load_lines(paths['mpoff']['paths']['-plans.jsonl']['path'])[:16]
        ctx=CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'), ROOT/'data/nofs-ids', seed)
        network={node['node_name']:node.get('network_map') or {} for node in ctx._base_infrastructure['nodes']}
        topology=ctx._base_infrastructure['link_topology']
        routes=topology['routes']
        bandwidth={key:float(value['bandwidth_mbps']) for key,value in topology['links'].items()}
        for snap,htrace,mtrace in zip(snaps,hand,mpoff):
            result=grouped[(seed,snap['snapshot_id'])]
            tasks=snapshot_tasks(snap,None)
            bases={'hand':trace_plan(htrace,tasks),'mpoff':trace_plan(mtrace,tasks)}
            pool,_=build_pool(tasks,bases)
            rows=result['rows']
            if len(pool)!=len(rows):
                raise ValueError('pool length mismatch')
            lookup=candidate_lookup(tasks)
            pairs=group_peer_exchange(snap,workload)
            adj,balls=neighbor_balls(pairs)
            for idx,((key,source),row) in enumerate(zip(pool,rows)):
                digest=hashlib.sha256(json.dumps(key).encode()).hexdigest()
                if digest!=row['placement_sha256'] or source!=row['source']:
                    raise ValueError('pool order/hash mismatch')
                source_tag=source.split(':')[1]
                source_key=plan_key(bases[source_tag])
                source_rtt=result[source_tag+'_baseline_rtt']
                features,changed,signature=feature_row(key,source_key,source_rtt,tasks,lookup,pairs,adj,balls,source_tag,network,routes,bandwidth)
                examples.append({'seed':seed,'snapshot_id':snap['snapshot_id'],'row':idx,
                                 'source':source,'changed':changed,'placement':key,
                                 'match_signature':signature,
                                 'rtt':row['rtt'],'source_rtt':source_rtt,
                                 'target_improvement':source_rtt-row['rtt'],
                                 'features':features})
    names=sorted({name for e in examples for name in e['features']})
    X=np.array([[e['features'].get(name,0.0) for name in names] for e in examples],dtype=float)
    y=np.array([e['target_improvement'] for e in examples],dtype=float)
    predictions={model_name:np.full(len(examples),np.nan) for model_name in MODELS}
    for heldout in SEEDS:
        train=np.array([e['seed']!=heldout for e in examples])
        test=~train
        for name,build in MODELS.items():
            model=build()
            model.fit(X[train],y[train])
            predictions[name][test]=model.predict(X[test])
    for name,pred in predictions.items():
        if not np.all(np.isfinite(pred)):
            raise ValueError('nonfinite held-out prediction')
        for e,p in zip(examples,pred):
            e[name+'_predicted_rtt']=e['source_rtt']-float(p)
    results=[]
    reversals=[]
    for seed in SEEDS:
        for snapshot_id in range(16):
            exact=grouped[(seed,snapshot_id)]
            candidates=[e for e in examples if e['seed']==seed and e['snapshot_id']==snapshot_id]
            record={'seed':seed,'snapshot_id':snapshot_id,'baseline_rtt':exact['baseline_rtt'],
                    'oracle_rtt':exact['oracle_rtt'],'proxy_hand_rtt':exact['hand_rtt']}
            for name in MODELS:
                ranked=sorted(candidates,key=lambda e:(e[name+'_predicted_rtt'],e['placement']))[:16]
                record[name+'_hand_rtt']=min(exact['baseline_rtt'],*(e['rtt'] for e in ranked))
                record[name+'_selected_rows']=[e['row'] for e in ranked]
                missed=min(candidates,key=lambda e:e['rtt'])
                record[name+'_best_oracle_rank']=1+sum(e[name+'_predicted_rtt']<missed[name+'_predicted_rtt'] for e in candidates)
                matching=[e for e in candidates if e['match_signature']==missed['match_signature'] and e['row']!=missed['row']]
                wrong=[e for e in matching if e[name+'_predicted_rtt']<missed[name+'_predicted_rtt'] and e['rtt']>missed['rtt']]
                if wrong:
                    competitor=max(wrong,key=lambda e:e['rtt']-missed['rtt'])
                    reversals.append({'seed':seed,'snapshot_id':snapshot_id,'model':name,
                                      'signature':missed['match_signature'],
                                      'true_better_row':missed['row'],'predicted_better_row':competitor['row'],
                                      'true_rtt_stake':competitor['rtt']-missed['rtt'],
                                      'predicted_rtt_reversal':missed[name+'_predicted_rtt']-competitor[name+'_predicted_rtt']})
            results.append(record)
    topology=[]
    for seed in SEEDS:
        rows=[r for r in results if r['seed']==seed]
        base=sum(r['baseline_rtt'] for r in rows)
        oracle=sum(r['oracle_rtt'] for r in rows)
        totals={field:sum(r[field] for r in rows) for field in ('proxy_hand_rtt','ridge_hand_rtt','extratrees_hand_rtt')}
        topology.append({'seed':seed,'baseline_rtt':base,'oracle_rtt':oracle,
                         'oracle_gain_pct':100*(base-oracle)/base,
                         'captures':{field:(base-total)/(base-oracle) if base>oracle else None for field,total in totals.items()},
                         'totals':totals})
    output={'contract':CONTRACT,'script_sha256':sha(__file__),'score_sha256':sha(args.scores),
            'feature_names':names,'examples':examples,'groups':results,'topologies':topology,
            'matched_reversals':reversals}
    args.out.write_text(json.dumps(output,separators=(',',':')))
    print(json.dumps({'script_sha256':output['script_sha256'],'score_sha256':output['score_sha256'],
                      'feature_count':len(names),'candidate_count':len(examples),'topologies':topology},indent=2))


if __name__=='__main__':main()
