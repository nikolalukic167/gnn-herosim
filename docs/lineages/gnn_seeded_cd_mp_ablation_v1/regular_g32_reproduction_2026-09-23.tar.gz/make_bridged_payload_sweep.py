import json
from pathlib import Path

src = json.loads(Path('/tmp/fixed-g32-bridge_shuffled-5120.json').read_text())
for scale in (0.1, 0.25, 0.5):
    data = dict(src)
    data['peer_exchange'] = [[i, j, float(b) * scale] for i, j, b in src['peer_exchange']]
    data['payload_scale'] = scale
    path = Path(f'/tmp/fixed-g32-bridge_shuffled-p{scale}-5120.json')
    path.write_text(json.dumps(data, separators=(',', ':')))
    print(path, len(data['peer_exchange']))
