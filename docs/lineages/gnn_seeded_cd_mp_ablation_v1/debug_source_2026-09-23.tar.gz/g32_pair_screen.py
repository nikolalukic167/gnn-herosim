import json
import math
import os
import statistics
import sys
from pathlib import Path
from scripts_cosim import live_snapshot_cosim_oracle as oracle
from scripts_cosim.make_warm_corpus import build_batch_workload

root=Path('/root/projects/my-herosim')
trace=json.loads(Path('/tmp/fixed-g32-burst-5120.json').read_text())
config_path=Path('/tmp/fixed-g32-config-9303.json')
cell=json.loads(config_path.read_text())
snapshots=[json.loads(l) for l in Path('/tmp/fixed-g32-snap-full.jsonl').read_text().splitlines()]
plans={tuple(int(i) for i in r['ids']):r for r in (json.loads(l) for l in Path('/tmp/fixed-g32-mpoff-plans.jsonl').read_text().splitlines())}
ctx=oracle.CosimOracleContext(config_path=config_path,sim_input_path=root/'data/nofs-ids',seed=9303)

def remote_weight(plan, edges, pair_to_node):
    return sum(float(b) for i,j,b in edges if pair_to_node[plan[i]] != pair_to_node[plan[j]])

out=[]
limit=int(sys.argv[1]) if len(sys.argv)>1 else 8
for snap in snapshots[:limit]:
    ids=[int(t['task_id']) for t in snap['tasks']]
    work=build_batch_workload(snap,trace,ids,list(cell['wsc']))
    byid={int(t['task_id']):t for t in snap['tasks']}
    tasks=[byid[tid] for tid in work['trace_task_ids']]
    baseline={i:tuple(plans[tuple(ids)]['final'][str(tid)]) for i,tid in enumerate(work['trace_task_ids'])}
    if len(baseline)!=32 or len(work['peer_exchange'])==0:
        raise RuntimeError('invalid group')
    candidates=[]
    pair_to_node={}
    for task in tasks:
        opts={}
        for c in task['candidates']:
            p=(int(c['node_id']),int(c['platform_id']))
            n=int(c['node_id'])
            if n in opts and opts[n]!=p:
                raise RuntimeError('multiple platforms per node')
            opts[n]=p;pair_to_node[p]=n
        candidates.append(opts)
    edges=[(int(i),int(j),float(b)) for i,j,b in work['peer_exchange']]
    edges.sort(key=lambda x:-x[2])
    variants={tuple(baseline[i] for i in range(32)):('baseline',0)}
    for rank,(i,j,b) in enumerate(edges[:40]):
        for node in candidates[i].keys() & candidates[j].keys():
            p=tuple(candidates[t][node] if t in (i,j) else baseline[t] for t in range(32))
            variants.setdefault(p,('pair',rank))
    incident={i:[] for i in range(32)}
    for rank,(i,j,b) in enumerate(edges[:40]):
        incident[i].append((j,rank,b));incident[j].append((i,rank,b))
    for i,neighbors in incident.items():
        neighbors.sort(key=lambda x:-x[2])
        for a in range(min(6,len(neighbors))):
            for b in range(a+1,min(6,len(neighbors))):
                j,k=neighbors[a][0],neighbors[b][0]
                for node in candidates[i].keys() & candidates[j].keys() & candidates[k].keys():
                    p=tuple(candidates[t][node] if t in (i,j,k) else baseline[t] for t in range(32))
                    variants.setdefault(p,('triple',min(neighbors[a][1],neighbors[b][1])))
    base_key=tuple(baseline[i] for i in range(32))
    sorted_variants=sorted(variants,key=lambda p:(remote_weight(p,edges,pair_to_node),sum(a!=b for a,b in zip(p,base_key)),p))
    selected=[base_key]+[p for p in sorted_variants if p!=base_key][:64]
    oracle.build_workload_from_snapshot=lambda _tasks,horizon_events=None,_w=work: _w
    evaluations=[]
    for p in selected:
        plan={i:p[i] for i in range(32)}
        if not ctx.validate_placement_plan(tasks,plan):raise RuntimeError('invalid candidate plan')
        cost=ctx.run_placement_plan(snap,tasks,plan)
        if not math.isfinite(cost): raise RuntimeError('nonfinite cost')
        evaluations.append((p,cost,remote_weight(p,edges,pair_to_node),variants[p][0]))
    base=evaluations[0][1]
    hand=min(evaluations,key=lambda x:(x[2],x[1]))
    best=min(evaluations,key=lambda x:x[1])
    row={'snapshot_id':snap['snapshot_id'],'task_ids':ids,'n_edges':len(edges),'n_variants':len(variants),'n_evaluated':len(evaluations),'baseline_cost':base,'best_cost':best[1],'best_move':best[3],'best_hamming':sum(a!=b for a,b in zip(best[0],base_key)),'hand_cost':hand[1],'headroom_pct':100*(base-best[1])/base,'hand_gain_pct':100*(base-hand[1])/base,'oracle_beyond_hand_pct':100*(hand[1]-best[1])/hand[1]}
    out.append(row)
    print(json.dumps(row),flush=True)
print('MEDIANS',json.dumps({k:statistics.median(r[k] for r in out) for k in ('headroom_pct','hand_gain_pct','oracle_beyond_hand_pct')}),flush=True)
Path('/tmp/fixed-g32-pair-screen.json').write_text(json.dumps(out,indent=2))
