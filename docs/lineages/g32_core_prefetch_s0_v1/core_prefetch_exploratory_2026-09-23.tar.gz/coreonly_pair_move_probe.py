#!/usr/bin/env python3
import hashlib
import json
import os
import sys
from pathlib import Path

ROOT = Path('/tmp/herosim_peer_coreonly')
sys.path[:0] = [str(ROOT), '/tmp']
from scripts_cosim.important.generate_sampled_slate_snapshots import (
    CosimOracleContext, group_events, group_peer_exchange, score_plan,
    snapshot_tasks, validate_snapshot_infrastructure,
)
from peer_coreonly_move_oracle import (
    candidate_lookup, load_lines, plan_dict, plan_key, proxy, trace_plan,
)

if any(os.environ.get(k) != '1' for k in ('HEROSIM_PEER_EXCHANGE','HEROSIM_PEER_FABRIC','HEROSIM_PEER_PREFETCH','HEROSIM_PEER_PREFETCH_CORE_ONLY','HEROSIM_PEER_PREFETCH_PIPES')):
    raise RuntimeError('finite core-only prefetch flags required')
seed = 9801
workload = json.loads(Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json').read_text())
old = json.loads(Path('/tmp/peer-coreonly-move-oracle-full.json').read_text())
old_by_id = {(r['seed'], r['snapshot_id']): r for r in old['results']}
prefix = f'/tmp/fourtype-train-{seed}'
snaps = load_lines(f'{prefix}-hand-snapshots.jsonl')[:4]
hand = load_lines(f'{prefix}-hand-plans.jsonl')[:4]
mpoff = load_lines(f'{prefix}-mpoff-plans.jsonl')[:4]
ctx = CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'), ROOT/'data/nofs-ids', seed)
out = {'contract':'coreonly_pair_move_exploratory_v1','seed':seed,'groups':[]}
for snap, ht, mt in zip(snaps, hand, mpoff):
    tasks = snapshot_tasks(snap, None)
    validate_snapshot_infrastructure(ctx,snap)
    bases = {'hand':trace_plan(ht,tasks),'mpoff':trace_plan(mt,tasks)}
    choices = [sorted({(int(c['node_id']),int(c['platform_id'])) for c in task['candidates']}) for task in tasks]
    pairs = group_peer_exchange(snap, workload)
    events = group_events(snap, workload)
    lookup = candidate_lookup(tasks)
    network = {n['node_name']: n.get('network_map') or {} for n in ctx._base_infrastructure['nodes']}
    old_result = old_by_id[(seed,snap['snapshot_id'])]
    old_hashes = {row['placement_sha256'] for row in old_result['rows']}
    seen = {plan_key(p) for p in bases.values()}
    pool = []
    eligible = 0
    for a,b,payload in sorted(((int(a),int(b),float(w)) for a,b,w in pairs),key=lambda x:(-x[2],x[0],x[1])):
        common = [(ca,cb) for ca in choices[a] for cb in choices[b] if ca[0]==cb[0]]
        for source,base in bases.items():
            key=plan_key(base)
            for ca,cb in common:
                if ca==key[a] or cb==key[b]:
                    continue
                eligible += 1
                moved=list(key);moved[a]=ca;moved[b]=cb;moved=tuple(moved)
                if moved in seen:
                    continue
                seen.add(moved)
                if len(pool)<128:
                    pool.append((moved,source,a,b,payload))
    scored=[]
    for key,source,a,b,payload in pool:
        rtt=float(score_plan(ctx,snap,tasks,plan_dict(key),pairs,events))
        digest=hashlib.sha256(json.dumps(key).encode()).hexdigest()
        scored.append({'rtt':rtt,'proxy':proxy(key,lookup,pairs,network),'source':source,'a':a,'b':b,'payload':payload,'already_in_old_pool':digest in old_hashes})
    best=min([old_result['oracle_rtt']]+[r['rtt'] for r in scored])
    top=sorted(scored,key=lambda r:(r['proxy'],r['a'],r['b']))[:16]
    hand_best=min([old_result['oracle_rtt']]+[r['rtt'] for r in top])
    rec={'snapshot_id':snap['snapshot_id'],'old_oracle_rtt':old_result['oracle_rtt'],'pair_augmented_oracle_rtt':best,'pair_hand_rtt':hand_best,'eligible_with_duplicates':eligible,'retained':len(pool),'overlap_old_pool':sum(r['already_in_old_pool'] for r in scored),'rows':scored}
    out['groups'].append(rec)
    print(snap['snapshot_id'],rec['old_oracle_rtt'],best,hand_best,len(pool),flush=True)
path=Path('/tmp/coreonly-pair-move-probe.json');path.write_text(json.dumps(out,separators=(',',':')))
base=sum(g['old_oracle_rtt'] for g in out['groups']);oracle=sum(g['pair_augmented_oracle_rtt'] for g in out['groups']);hand_total=sum(g['pair_hand_rtt'] for g in out['groups'])
print('incremental_gain_pct',100*(base-oracle)/base,'hand_capture',(base-hand_total)/(base-oracle) if base>oracle else None)
