import json
import random
from pathlib import Path

src = json.loads(Path('/tmp/fixed-g32-burst-5120.json').read_text())
old = src['peer_exchange']
for kind in ('bridge', 'bridge_shuffled'):
    rng = random.Random(230924)
    data = dict(src)
    edges = []
    for group in range(160):
        payload = sum(float(b) for i, j, b in old if i // 32 == group)
        weight = payload / 64
        labels = list(range(32))
        if kind == 'bridge_shuffled':
            rng.shuffle(labels)
        local_edges = set()
        for block in range(4):
            segment = list(range(block * 8, (block + 1) * 8))
            for index in range(8):
                for offset in (1, 2):
                    local_edges.add(tuple(sorted((segment[index], segment[(index + offset) % 8]))))
        for block in range(4):
            nxt = (block + 1) % 4
            a = tuple(sorted((block * 8 + 4, block * 8 + 5)))
            b = tuple(sorted((nxt * 8, nxt * 8 + 1)))
            assert a in local_edges and b in local_edges
            local_edges.remove(a)
            local_edges.remove(b)
            local_edges.add(tuple(sorted((block * 8 + 4, nxt * 8))))
            local_edges.add(tuple(sorted((block * 8 + 5, nxt * 8 + 1))))
        assert len(local_edges) == 64
        degree = [0] * 32
        adj = [set() for _ in range(32)]
        for i, j in local_edges:
            degree[i] += 1
            degree[j] += 1
            adj[i].add(j)
            adj[j].add(i)
            x, y = sorted((labels[i], labels[j]))
            edges.append([group * 32 + x, group * 32 + y, weight])
        assert set(degree) == {4}
        seen = {0}
        todo = [0]
        while todo:
            for v in adj[todo.pop()] - seen:
                seen.add(v)
                todo.append(v)
        assert len(seen) == 32
        assert abs(64 * weight - payload) < 1e-8
    data['peer_exchange'] = edges
    data['regular_peer'] = {'kind': kind, 'degree': 4, 'connected': True, 'weight_per_edge': 'group_payload_divided_by_64', 'seed': 230924}
    path = Path(f'/tmp/fixed-g32-{kind}-5120.json')
    path.write_text(json.dumps(data, separators=(',', ':')))
    print(kind, path, len(edges))
