import hashlib,json,os,pathlib,subprocess
base=json.load(open('/tmp/fixed-g32-config-9819.json'))
root='/tmp/herosim_peer_coreonly'
env=os.environ.copy()
env.update({'PIPENV_IGNORE_VIRTUALENVS':'1','VIRTUAL_ENV':'','PYTHONPATH':root,
 'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONHASHSEED':'0','MPLCONFIGDIR':'/tmp/mplcache',
 'HEROSIM_PG_EXCHANGE_SCALE':'4','HEROSIM_PG_CD_PASSES':'6','HEROSIM_PEER_EXCHANGE':'1',
 'HEROSIM_PEER_FABRIC':'1','HEROSIM_PEER_PREFETCH':'1','HEROSIM_PEER_PREFETCH_PIPES':'1',
 'HEROSIM_PEER_PREFETCH_CORE_ONLY':'1','HEROSIM_SERVER_ONLY_REPLICAS':'1',
 'HEROSIM_WARMTH_PHYSICS':'node_disk_v2','FIXED_REPLICA_PREFLIGHT':'1',
 'GNN_DECODE_MODE':'masked_topo','GNN_BATCH_BY_PEER_GROUP':'1','GNN_BATCH_SIZE':'32',
 'GNN_PREFIX_ALPHA_KEY':'inf','GNN_QUEUE_NORM_MODE':'scheduler_adaptive',
 'QUEUE_FEATURE_CONTRACT':'legacy_v0','HEROSIM_GNN_DEVICE':'cpu',
 'GNN_MODEL_PATH':'/tmp/jb2-mpoff-seed1.pt'})
selected=[];rejected=[]
for seed in range(9823,9860):
    config=json.loads(json.dumps(base))
    config['network']['topology']['seed']=seed
    config['gate_cell']['topology_seed']=seed
    path=pathlib.Path(f'/tmp/fixed-g32-config-{seed}.json')
    path.write_text(json.dumps(config,indent=2,sort_keys=True)+'\n')
    env['FIXED_REPLICA_MANIFEST_PATH']=f'/tmp/valley-live-{seed}-preflight-manifest.json'
    env['FIXED_TRACE_PATH']=f'/tmp/valley-live-{seed}-preflight-trace.jsonl'
    cmd=['pipenv','run','python3','/tmp/fixed_g32_hand_trace_runner.py','--config',str(path),
         '--workload','/tmp/fixed-g32-fourtype-lowpayload-5120.json',
         '--policy','peer_greedy_network_cd','--queue-length','100',
         '--output',f'/tmp/valley-live-{seed}-preflight.json']
    p=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    pathlib.Path(f'/tmp/valley-live-{seed}-preflight.log').write_text(p.stdout)
    if p.returncode==0:
        selected.append(seed);print('ELIGIBLE',seed,flush=True)
    elif 'fixed-replica pool does not cover every source' in p.stdout:
        rejected.append(seed);print('INELIGIBLE',seed,flush=True)
    else:raise RuntimeError(f'preflight error {seed} code={p.returncode}')
    if len(selected)==2:break
freeze={'contract':'g32_coordinated_valley_live_selection_v1','selected':selected,'rejected':rejected,
        'configs':{str(seed):hashlib.sha256(pathlib.Path(f'/tmp/fixed-g32-config-{seed}.json').read_bytes()).hexdigest() for seed in selected}}
pathlib.Path('/tmp/valley-live-seed-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(freeze,flush=True)
