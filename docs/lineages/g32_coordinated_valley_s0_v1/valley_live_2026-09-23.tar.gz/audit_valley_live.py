import hashlib,json,pathlib
P=pathlib.Path
F=json.load(open('/tmp/valley-live-freeze.json'))
for path,digest in F['files'].items():
    assert hashlib.sha256(P(path).read_bytes()).hexdigest()==digest,path
rows=[]
for seed in F['seeds']:
    manifests=[]
    for arm in F['arms']:
        prefix=f'/tmp/valley-live-{seed}-{arm}-finite'
        x=json.load(open(prefix+'-s4.json'));s=x['stats']
        assert x['status']=='success' and x['num_tasks']==s['num_tasks']==5120
        assert not s['scaleEvents'] and s['totalPeerExchangeTime']>0
        assert s['peerFabricCoreWaitTotal']>0 and s['peerFabricWaitTotal']>=s['peerFabricCoreWaitTotal']
        assert s['schedulerCounters']['prefix_batches']==160
        assert s['schedulerCounters']['prefix_tasks_decoded']==5120
        assert s['schedulerCounters']['fallback_decisions']==0
        plans=[json.loads(line) for line in open(prefix+'-plans.jsonl')]
        assert len(plans)==160
        assert [i for p in plans for i in p['ids']]==list(range(5120))
        for p in plans:assert len(p['ids'])==len(p['final'])==32
        snapshots=[json.loads(line) for line in open(prefix+'-snapshots.jsonl')]
        assert len(snapshots)==16
        manifest=json.load(open(prefix+'-manifest.json'))
        manifests.append(manifest)
        rows.append({'seed':seed,'arm':arm,'rtt':s['total_rtt'],'core_wait':s['peerFabricCoreWaitTotal'],
                     'peer_wait':s['peerFabricWaitTotal'],'peer_exchange':s['totalPeerExchangeTime'],
                     'fabric_wait':s['fabricLinkWaitTotal'],'plans':len(plans),'snapshots':len(snapshots)})
    assert manifests[0]==manifests[1]
out={'contract':'g32_coordinated_valley_live_audit_v1',
     'freeze_sha256':hashlib.sha256(P('/tmp/valley-live-freeze.json').read_bytes()).hexdigest(),
     'rows':rows}
P('/tmp/valley-live-audit.json').write_text(json.dumps(out,indent=2)+'\n')
for row in rows:print(row['seed'],row['arm'],'rtt',round(row['rtt'],3),'core_wait_share_pct',round(100*row['core_wait']/row['rtt'],3))
print('AUDIT PASS',len(rows),'runs',sum(r['plans']*32 for r in rows),'tasks')
