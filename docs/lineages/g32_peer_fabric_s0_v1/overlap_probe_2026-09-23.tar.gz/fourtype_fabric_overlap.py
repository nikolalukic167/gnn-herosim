#!/usr/bin/env python3
import collections
import json
import statistics
import sys
from pathlib import Path

ROOT=Path('/root/projects/my-herosim')
sys.path[:0]=[str(ROOT),'/tmp']
from fourtype_move_oracle_s0 import build_pool, candidate_lookup, load_lines, plan_key, trace_plan
from scripts_cosim.important.generate_sampled_slate_snapshots import CosimOracleContext, snapshot_tasks, group_peer_exchange
from src.placement.network_fabric import route_links, is_core_link

workload=json.loads(Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json').read_text())
scored=json.loads(Path('/tmp/fourtype-move-oracle-s0-full.json').read_text())
score_by={(row['seed'],row['snapshot_id']):row for row in scored['results']}
out={'contract':'fourtype_peer_fabric_overlap_exploratory_v1','groups':[]}
for seed in [9801,9803,9804,9806]:
    ctx=CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'),ROOT/'data/nofs-ids',seed)
    routes=ctx._base_infrastructure['link_topology']['routes']
    bandwidth={link:float(attrs['bandwidth_mbps'])*1024*1024 for link,attrs in ctx._base_infrastructure['link_topology']['links'].items()}
    snaps=load_lines(f'/tmp/fourtype-train-{seed}-hand-snapshots.jsonl')[:16]
    hand=load_lines(f'/tmp/fourtype-train-{seed}-hand-plans.jsonl')[:16]
    mpoff=load_lines(f'/tmp/fourtype-train-{seed}-mpoff-plans.jsonl')[:16]
    for snap,ht,mt in zip(snaps,hand,mpoff):
        tasks=snapshot_tasks(snap,None)
        bases={'hand':trace_plan(ht,tasks),'mpoff':trace_plan(mt,tasks)}
        pool,_=build_pool(tasks,bases)
        candidates=[(plan_key(bases['hand']),'hand'),(plan_key(bases['mpoff']),'mpoff')]+pool
        peers=group_peer_exchange(snap,workload)
        lookup=candidate_lookup(tasks)
        rec=score_by[(seed,snap['snapshot_id'])]
        if len(pool)!=len(rec['rows']):raise ValueError('move pool mismatch')
        outcomes=[]
        for idx,(plan,source) in enumerate(candidates):
            node=[lookup[i][p]['node_name'] for i,p in enumerate(plan)]
            flows=collections.defaultdict(list)
            for a,b,payload in peers:
                a=int(a);b=int(b)
                if node[a]==node[b]:continue
                for link in route_links(routes,node[a],node[b]):
                    if is_core_link(link):flows[link].append(float(payload)/bandwidth[link])
            k=max((len(v) for v in flows.values()),default=0)
            wait=sum(sum((len(v)-j-1)*d for j,d in enumerate(sorted(v,reverse=True))) for v in flows.values())
            rtt=[rec['hand_baseline_rtt'],rec['mpoff_baseline_rtt']][idx] if idx<2 else rec['rows'][idx-2]['rtt']
            outcomes.append({'source':source,'k_core':k,'synthetic_core_wait':wait,'original_rtt':rtt,'augmented_cost':rtt+wait})
        old_best=min(outcomes,key=lambda r:r['original_rtt'])
        new_best=min(outcomes,key=lambda r:r['augmented_cost'])
        out['groups'].append({'seed':seed,'snapshot_id':snap['snapshot_id'],'pool_size':len(outcomes),'core_share_fraction':sum(r['k_core']>=2 for r in outcomes)/len(outcomes),'min_k_core':min(r['k_core'] for r in outcomes),'min_wait':min(r['synthetic_core_wait'] for r in outcomes),'old_best':old_best,'new_best':new_best})
    rows=[r for r in out['groups'] if r['seed']==seed]
    print(seed,'median min core k',statistics.median(r['min_k_core'] for r in rows),'median old-best k',statistics.median(r['old_best']['k_core'] for r in rows),'median new-best k',statistics.median(r['new_best']['k_core'] for r in rows),'new-best nonzero core',sum(r['new_best']['k_core']>=2 for r in rows),'median new wait share',statistics.median(r['new_best']['synthetic_core_wait']/r['new_best']['augmented_cost'] for r in rows),flush=True)
Path('/tmp/fourtype-fabric-overlap.json').write_text(json.dumps(out,separators=(',',':')))
