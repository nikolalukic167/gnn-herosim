import json
import os
import sys
from pathlib import Path

sys.path.insert(0, '/tmp/herosim_peer_coreonly')
from scripts_cosim.important.generate_sampled_slate_snapshots import (
    CosimOracleContext, full_result, group_events, group_peer_exchange,
    snapshot_tasks,
)

seed=int(sys.argv[1])
group=int(sys.argv[2])
arm=sys.argv[3]
capture=os.environ.get('CAPTURE_PREFIX',f'/tmp/fourtype-train-{seed}')
snap_path=(f'{capture}-snapshots.jsonl' if 'dev' in capture else f'{capture}-hand-snapshots.jsonl')
trace_path=(f'{capture}-plans.jsonl' if 'dev' in capture else f'{capture}-{arm}-plans.jsonl')
snap=json.loads(Path(snap_path).read_text().splitlines()[group])
trace=json.loads(Path(trace_path).read_text().splitlines()[group])
tasks=snapshot_tasks(snap,None)
ids=[int(t['task_id']) for t in tasks]
assert trace['ids']==ids
plan={i:tuple(map(int,trace['final'][str(task_id)])) for i,task_id in enumerate(ids)}
workload=json.loads(Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json').read_text())
ctx=CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'),Path('/tmp/herosim_peer_coreonly/data/nofs-ids'),seed)
if os.environ.get('NO_FABRIC')=='1':
    ctx._base_infrastructure['link_topology']=None
core_bw=os.environ.get('CORE_BW')
if core_bw is not None:
    from src.placement.network_fabric import is_core_link
    for link,attrs in ctx._base_infrastructure['link_topology']['links'].items():
        if is_core_link(link):
            attrs['bandwidth_mbps']=float(core_bw)
pairs=group_peer_exchange(snap,workload)
scale=float(os.environ.get('PAIR_SCALE','1'))
pairs=[[a,b,payload*scale] for a,b,payload in pairs]
result=full_result(ctx,snap,tasks,plan,pairs,group_events(snap,workload))
stats=result['stats']
print(json.dumps({'rtt':stats['total_rtt'],'num_tasks':stats['num_tasks'],
 'peer':stats['totalPeerExchangeTime'],'core_wait':stats.get('peerFabricCoreWaitTotal'),
 'peer_wait':stats.get('peerFabricWaitTotal'),'peer_transfer':stats.get('peerFabricTransferTotal'),
 'link_wait':stats['totalLinkWaitTime'],'status':result.get('status')}))
