#!/usr/bin/env python3
"""Frozen leave-one-topology-out route-aware 16-evaluation pair control."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path('/tmp/herosim_peer_coreonly')
sys.path[:0] = [str(ROOT), '/tmp']
from scripts_cosim.important.generate_sampled_slate_snapshots import CosimOracleContext, group_peer_exchange, snapshot_tasks
from peer_coreonly_move_oracle import candidate_lookup, load_lines, plan_key, trace_plan, proxy, sha
from peer_coreonly_move_residual import feature_row, neighbor_balls
from coreonly_valley_s0 import SEEDS, GROUPS, WORKLOAD, MANIFEST, pair_pool, digest

MODELS = {
    'ridge': lambda: make_pipeline(SimpleImputer(strategy='constant', fill_value=0), StandardScaler(), Ridge(alpha=10.0)),
    'extratrees': lambda: ExtraTreesRegressor(n_estimators=300, min_samples_leaf=2,
                                              max_features=1.0, random_state=730, n_jobs=1),
}
CONTRACT = {'version': 'g32_coordinated_valley_hand_v1', 'split': 'leave_one_topology_out',
            'exact_joint_evaluations_per_group': 16, 'source_baseline_evaluations': 2,
            'models': {'ridge_alpha': 10.0, 'extratrees_n': 300,
                       'extratrees_min_leaf': 2, 'extratrees_seed': 730},
            'feature_source': 'prior frozen route-aware 1/2/4-hop and core-link feature function plus pair payload and source physical proxy',
            'selection': 'lowest predicted joint RTT, lexicographic placement tie break'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scores', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    scores = json.loads(args.scores.read_text())
    if len(scores['results']) != len(SEEDS)*len(GROUPS):
        raise ValueError('incomplete scores')
    result_by = {(r['seed'], r['snapshot_id']): r for r in scores['results']}
    manifest = json.loads(MANIFEST.read_text())
    workload = json.loads(WORKLOAD.read_text())
    examples = []
    for seed in SEEDS:
        paths = manifest['seeds'][str(seed)]['arms']
        snaps = load_lines(paths['hand']['paths']['-snapshots.jsonl']['path'])[4:16]
        hand = load_lines(paths['hand']['paths']['-plans.jsonl']['path'])[4:16]
        mpoff = load_lines(paths['mpoff']['paths']['-plans.jsonl']['path'])[4:16]
        ctx = CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'), ROOT/'data/nofs-ids', seed)
        net = {node['node_name']: node.get('network_map') or {} for node in ctx._base_infrastructure['nodes']}
        topo = ctx._base_infrastructure['link_topology']
        routes = topo['routes']
        bandwidth = {key: float(val['bandwidth_mbps']) for key, val in topo['links'].items()}
        for snap, htrace, mtrace in zip(snaps, hand, mpoff):
            tasks = snapshot_tasks(snap, None)
            result = result_by[(seed, snap['snapshot_id'])]
            bases = {'hand': trace_plan(htrace, tasks), 'mpoff': trace_plan(mtrace, tasks)}
            source_arm = result['source_arm']
            base = plan_key(bases[source_arm])
            lookup = candidate_lookup(tasks)
            pairs = group_peer_exchange(snap, workload)
            adj, balls = neighbor_balls(pairs)
            pool, _ = pair_pool(base, tasks, pairs)
            if len(pool) != len(result['rows']):
                raise ValueError('pool size mismatch')
            source_proxy = proxy(base, lookup, pairs, net)
            for idx, ((key, a, b, payload), row) in enumerate(zip(pool, result['rows'])):
                if digest(key) != row['placement_sha256'] or (a, b, payload) != (row['a'], row['b'], row['payload']):
                    raise ValueError('pair pool hash/order mismatch')
                f, changed, _ = feature_row(key, base, result['baseline_rtt'], tasks,
                                            lookup, pairs, adj, balls, source_arm, net, routes, bandwidth)
                if sorted(changed) != sorted((a, b)):
                    raise ValueError('pair change mismatch')
                f.update({'pair_payload': payload, 'source_proxy': source_proxy,
                          'proxy_delta': row['simple_proxy']-source_proxy,
                          'pair_direct_edge': float(b in adj[a]),
                          'pair_same_destination_node': float(key[a][0] == key[b][0]),
                          'pair_source_same_node': float(base[a][0] == base[b][0])})
                examples.append({'seed': seed, 'snapshot_id': snap['snapshot_id'], 'row': idx,
                                 'key': key, 'joint_rtt': row['joint_rtt'],
                                 'baseline_rtt': result['baseline_rtt'],
                                 'target': result['baseline_rtt']-row['joint_rtt'],
                                 'features': f})
    names = sorted({k for e in examples for k in e['features']})
    X = np.array([[e['features'].get(k, 0.0) for k in names] for e in examples], dtype=float)
    y = np.array([e['target'] for e in examples], dtype=float)
    pred = {name: np.full(len(examples), np.nan) for name in MODELS}
    for heldout in SEEDS:
        train = np.array([e['seed'] != heldout for e in examples])
        for name, build in MODELS.items():
            model = build()
            model.fit(X[train], y[train])
            pred[name][~train] = model.predict(X[~train])
    if any(not np.all(np.isfinite(values)) for values in pred.values()):
        raise ValueError('nonfinite predictions')
    out = {'contract': CONTRACT, 'script_sha256': sha(__file__),
           'score_sha256': sha(args.scores), 'feature_names': names, 'groups': [], 'topologies': []}
    for seed in SEEDS:
        for snapshot_id in GROUPS:
            r = result_by[(seed, snapshot_id)]
            indices = [i for i, e in enumerate(examples) if e['seed'] == seed and e['snapshot_id'] == snapshot_id]
            cell = {'seed': seed, 'snapshot_id': snapshot_id,
                    'baseline_rtt': r['baseline_rtt'], 'oracle_rtt': r['all_pair_oracle_rtt'],
                    'material_valley_oracle_rtt': r['material_valley_oracle_rtt']}
            for name in MODELS:
                selected = sorted(indices, key=lambda i: (r['baseline_rtt']-pred[name][i], examples[i]['key']))[:16]
                cell[name+'_rtt'] = min([r['baseline_rtt']]+[examples[i]['joint_rtt'] for i in selected])
                cell[name+'_selected_rows'] = [examples[i]['row'] for i in selected]
            out['groups'].append(cell)
        rows = [r for r in out['groups'] if r['seed'] == seed]
        base = sum(r['baseline_rtt'] for r in rows)
        oracle = sum(r['oracle_rtt'] for r in rows)
        totals = {name: sum(r[name+'_rtt'] for r in rows) for name in MODELS}
        out['topologies'].append({'seed': seed, 'baseline_rtt': base, 'oracle_rtt': oracle,
                                  'oracle_gain_pct': 100*(base-oracle)/base,
                                  'capture': {name: (base-value)/(base-oracle) if base>oracle else None
                                              for name, value in totals.items()}})
    args.out.write_text(json.dumps(out, separators=(',', ':')))
    print(json.dumps({'script_sha256': out['script_sha256'], 'score_sha256': out['score_sha256'],
                      'features': len(names), 'candidate_count': len(examples),
                      'topologies': out['topologies']}, indent=2))


if __name__ == '__main__':
    main()
