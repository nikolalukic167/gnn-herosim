import argparse
import collections
import hashlib
import json
import random
from pathlib import Path


TYPES = ("cnn", "dnn2", "rf", "dnn1")


def build(source: Path, target: Path) -> dict:
    workload = json.loads(source.read_text())
    events = workload["events"]
    assert len(events) == 5120
    groups = collections.defaultdict(list)
    for idx, event in enumerate(events):
        groups[event["peer_group"]].append(idx)
    assert len(groups) == 160 and all(len(v) == 32 for v in groups.values())
    assert list(sorted(groups)) == list(range(160))

    histograms = collections.Counter()
    island_histograms = collections.Counter()
    for group, indices in sorted(groups.items()):
        rng = random.Random(902300 + group)
        cnn_count = 2 + group % 5
        dnn2_count = 6 + (group * 3) % 5
        rf_count = 7 + (group * 7) % 3
        counts = (cnn_count, dnn2_count, rf_count, 32 - cnn_count - dnn2_count - rf_count)
        labels = [kind for kind, count in zip(TYPES, counts) for _ in range(count)]
        rng.shuffle(labels)
        assert len(labels) == 32
        histograms[counts] += 1
        for position, (idx, kind) in enumerate(zip(indices, labels)):
            event = events[idx]
            old_application = event["application"]
            old_kind = next(iter(old_application["dag"]))
            scalar = old_application["demand_scale"][old_kind]
            event["application"] = {
                **old_application,
                "name": f"nofs-{kind}",
                "dag": {kind: []},
                "demand_scale": {kind: scalar},
            }
            island_histograms[(position // 16, kind)] += 1

    original_pairs = workload["peer_exchange"]
    workload["peer_exchange"] = [[a, b, bytes_ * 0.1] for a, b, bytes_ in original_pairs]
    workload["payload_scale"] = workload.get("payload_scale", 1) * 0.1
    workload["fourtype_transform"] = {
        "source": str(source),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "seed_base": 902300,
        "group_histograms": {str(k): v for k, v in sorted(histograms.items())},
        "payload_multiplier": 0.1,
        "type_order": list(TYPES),
    }
    target.write_text(json.dumps(workload, separators=(",", ":")) + "\n")
    rebuilt = json.loads(target.read_text())
    assert [e["timestamp"] for e in events] == [e["timestamp"] for e in rebuilt["events"]]
    assert [e["node_name"] for e in events] == [e["node_name"] for e in rebuilt["events"]]
    assert [e["peer_group"] for e in events] == [e["peer_group"] for e in rebuilt["events"]]
    assert [(a, b) for a, b, _ in original_pairs] == [(a, b) for a, b, _ in rebuilt["peer_exchange"]]
    return {
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "workload_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "events": len(events),
        "groups": len(groups),
        "pairs": len(original_pairs),
        "types": dict(collections.Counter(next(iter(e["application"]["dag"])) for e in events)),
        "group_histograms": {str(k): v for k, v in sorted(histograms.items())},
        "island_types": {f"{island}:{kind}": count for (island, kind), count in sorted(island_histograms.items())},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("/tmp/fixed-g32-weighted_bridge-5120.json"))
    parser.add_argument("--target", type=Path, default=Path("/tmp/fixed-g32-fourtype-lowpayload-5120.json"))
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.target), indent=2, sort_keys=True))
