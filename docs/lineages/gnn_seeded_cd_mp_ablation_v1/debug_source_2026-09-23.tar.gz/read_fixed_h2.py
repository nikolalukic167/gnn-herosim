import json,statistics
from pathlib import Path
root=Path('/tmp/fixed9303-forced4096-sweeps')
traces={tuple(int(i) for i in r['ids']):r for r in (json.loads(l) for l in open('/tmp/fixed9303-mpoff-plans.jsonl'))}
rows=[]
for d in sorted(root.glob('ds_*')):
 p=d/'placements'/'placements.jsonl'
 if not p.exists():continue
 ids=json.loads((d/'workload.json').read_text())['trace_task_ids']
 baseplan={str(i):traces[tuple(sorted(ids))]['final'][str(t)] for i,t in enumerate(ids)}
 sweep=[json.loads(l) for l in open(p)]
 h=lambda x:sum(x['placement_plan'][str(i)]!=baseplan[str(i)] for i in range(len(ids)))
 base=next(x for x in sweep if x['placement_plan']==baseplan)
 h2=[x for x in sweep if h(x)<=2]
 h2best=min(h2,key=lambda x:x['rtt'])
 exch=min(h2,key=lambda x:(x['peer_exchange_total'],h(x)))
 full=min(sweep,key=lambda x:x['rtt'])
 row={'snapshot':json.load(open(d/'warm_snapshot.json'))['provenance']['snapshot_id'],'base':base['rtt'],'full_best':full['rtt'],'hfull':h(full),'h2_best':h2best['rtt'],'hand_exchange_h2':exch['rtt'],'h2_count':len(h2),'base_exchange':base['peer_exchange_total'],'best_exchange':full['peer_exchange_total']}
 rows.append(row)
 print({k:round(v,3) if isinstance(v,float) else v for k,v in row.items()})
print('median_full_headroom',statistics.median(100*(r['base']-r['full_best'])/r['base'] for r in rows))
print('median_h2_headroom',statistics.median(100*(r['base']-r['h2_best'])/r['base'] for r in rows))
print('median_hand_headroom',statistics.median(100*(r['base']-r['hand_exchange_h2'])/r['base'] for r in rows))
print('weighted',sum(r['base'] for r in rows),sum(r['full_best'] for r in rows),sum(r['h2_best'] for r in rows),sum(r['hand_exchange_h2'] for r in rows))
Path('/tmp/fixed9303-forced4096-analysis.json').write_text(json.dumps(rows,indent=2))
