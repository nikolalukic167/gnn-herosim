import json,random,statistics
from pathlib import Path
src=Path('/tmp/fixed-g32-burst-5120.json');d=json.loads(src.read_text())
rng=random.Random(991)
old=d['peer_exchange'];bygroup={}
for i,j,b in old:
    if i//32!=j//32:raise RuntimeError('cross-group edge')
    bygroup.setdefault(i//32,[]).append(float(b))
pairs=[];records=[]
for g in range(160):
    oldb=bygroup[g]
    links=set()
    for i in range(32):
        p1=[j for j in range(32) if j!=i and j//8==i//8]
        p2=[j for j in range(32) if j!=i and ((j+4)%32)//8==((i+4)%32)//8]
        for j in (rng.choice(p1),rng.choice(p2)):
            links.add((min(i,j),max(i,j)))
    links=sorted(links)
    draws=[rng.choice(oldb) for _ in links]
    scale=sum(oldb)/sum(draws)
    for (i,j),b in zip(links,draws):pairs.append([32*g+i,32*g+j,b*scale])
    records.append({'group':g,'old_edges':len(oldb),'new_edges':len(links),'old_bytes':sum(oldb),'new_bytes':sum(draws)*scale})
d['peer_exchange']=pairs
d['structured_peer']={'kind':'two_overlapping_8_task_partitions','seed':991,'partners_per_task':2,'same_per_group_payload_total':True,'source':str(src)}
out=Path('/tmp/fixed-g32-structured-5120.json');out.write_text(json.dumps(d,separators=(',',':')))
print(out,'groups',len(records),'edges',len(pairs),'old_edges',len(old),'edge_median',statistics.median(r['new_edges'] for r in records),'old_median',statistics.median(r['old_edges'] for r in records),'max_total_relative_error',max(abs(r['old_bytes']-r['new_bytes'])/r['old_bytes'] for r in records))
