import json
import random
from pathlib import Path

src = json.loads(Path('/tmp/fixed-g32-bridge_shuffled-p0.5-5120.json').read_text())
old = src['peer_exchange']
rng = random.Random(230925)
edges = []
for group in range(160):
    payload = sum(float(b) for i, j, b in old if i // 32 == group)
    average = payload / 64
    heavy_weight = 1.6 * average
    light_weight = 0.4 * average
    labels = list(range(32))
    rng.shuffle(labels)
    heavy, light = set(), set()
    for block in range(4):
        segment = list(range(block * 8, (block + 1) * 8))
        for index in range(8):
            for offset, target in ((1, heavy), (2, light)):
                target.add(tuple(sorted((segment[index], segment[(index + offset) % 8]))))
    for block in range(4):
        nxt = (block + 1) % 4
        a = tuple(sorted((block * 8 + 4, block * 8 + 5)))
        b = tuple(sorted((nxt * 8, nxt * 8 + 1)))
        heavy.remove(a)
        heavy.remove(b)
        heavy.add(tuple(sorted((block * 8 + 4, nxt * 8))))
        heavy.add(tuple(sorted((block * 8 + 5, nxt * 8 + 1))))
    assert len(heavy) == len(light) == 32
    degree = [0] * 32
    mass = [0.0] * 32
    adj = [set() for _ in range(32)]
    for target, weight in ((heavy, heavy_weight), (light, light_weight)):
        for i, j in target:
            degree[i] += 1
            degree[j] += 1
            mass[i] += weight
            mass[j] += weight
            adj[i].add(j)
            adj[j].add(i)
            x, y = sorted((labels[i], labels[j]))
            edges.append([32 * group + x, 32 * group + y, weight])
    assert set(degree) == {4}
    assert max(abs(x - 4 * average) for x in mass) / (4 * average) < 1e-12
    seen = {0}
    todo = [0]
    while todo:
        for v in adj[todo.pop()] - seen:
            seen.add(v)
            todo.append(v)
    assert len(seen) == 32
    assert abs(32 * heavy_weight + 32 * light_weight - payload) / payload < 1e-12
data = dict(src)
data['peer_exchange'] = edges
data['regular_peer'] = {'kind': 'weighted_bridge_shuffled', 'degree': 4, 'connected': True, 'weighted_degree': 'constant_within_group', 'heavy_to_light_ratio': 4, 'seed': 230925}
path = Path('/tmp/fixed-g32-weighted_bridge-5120.json')
path.write_text(json.dumps(data, separators=(',', ':')))
print(path, len(edges))
