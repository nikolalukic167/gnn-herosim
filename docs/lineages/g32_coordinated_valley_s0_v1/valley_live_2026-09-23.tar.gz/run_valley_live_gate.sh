#!/usr/bin/env bash
set -euo pipefail
seed="$1"
arm="$2"
case "$seed" in 9823|9824) ;; *) exit 2;; esac
case "$arm" in
  mpoff) runner=/tmp/fourtype_mpoff_trace_runner.py; policy=gnn_seeded_cd;;
  hand) runner=/tmp/fixed_g32_hand_trace_runner.py; policy=peer_greedy_network_cd;;
  *) exit 2;;
esac
mode="$3"
case "$mode" in finite) fabric=1; prefetch=1; pipes=1;; *) exit 2;; esac
prefix="/tmp/valley-live-${seed}-${arm}-${mode}"
export PIPENV_IGNORE_VIRTUALENVS=1 VIRTUAL_ENV= PYTHONPATH=/tmp/herosim_peer_coreonly MPLCONFIGDIR=/tmp/mplcache
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONHASHSEED=0
export HEROSIM_PG_EXCHANGE_SCALE=4 HEROSIM_PG_CD_PASSES=6 HEROSIM_PEER_EXCHANGE=1 HEROSIM_PEER_FABRIC="$fabric" HEROSIM_PEER_PREFETCH="$prefetch" HEROSIM_PEER_PREFETCH_PIPES="$pipes" HEROSIM_PEER_PREFETCH_CORE_ONLY=1
export HEROSIM_SERVER_ONLY_REPLICAS=1 HEROSIM_WARMTH_PHYSICS=node_disk_v2
export GNN_MODEL_PATH=/tmp/jb2-mpoff-seed1.pt GNN_DECODE_MODE=masked_topo GNN_QUEUE_NORM_MODE=scheduler_adaptive
export GNN_BATCH_BY_PEER_GROUP=1 GNN_BATCH_SIZE=32 GNN_PREFIX_ALPHA_KEY=inf
export GNN_DISABLE_MESSAGE_PASSING=1 GNN_MP_PLATFORM_EDGES_OFF=0
export PARTIAL_STATE_CONTRACT=partial_state_v3 PARTIAL_STATE_PEER_MASS=1
export INFERENCE_FEATURE_LAYOUT=dim22 TOPOLOGY_FEATURE_CONTRACT=src_index_v0
export QUEUE_FEATURE_CONTRACT=legacy_v0 HEROSIM_GNN_DEVICE=cpu
export FIXED_REPLICA_MANIFEST_PATH="${prefix}-manifest.json"
export FIXED_TRACE_PATH="${prefix}-plans.jsonl"
export LIVE_AUDIT_SNAPSHOT_PATH="${prefix}-snapshots.jsonl"
export LIVE_AUDIT_MAX_SNAPSHOTS=16 LIVE_AUDIT_STRIDE=32
export LIVE_AUDIT_MIN_BATCH_SIZE=32 LIVE_AUDIT_MIN_CANDIDATES=1
TIMEFORMAT='WALL_SECONDS=%R USER_CPU_SECONDS=%U SYSTEM_CPU_SECONDS=%S'
time pipenv run python3 "$runner" \
 --config "/tmp/fixed-g32-config-${seed}.json" \
 --workload /tmp/fixed-g32-fourtype-lowpayload-5120.json \
 --policy "$policy" --queue-length 100 \
 --output "${prefix}-s4.json"
