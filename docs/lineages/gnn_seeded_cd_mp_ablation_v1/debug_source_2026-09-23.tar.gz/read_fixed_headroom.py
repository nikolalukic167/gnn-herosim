import json
import statistics
from pathlib import Path
import sys
root=Path(sys.argv[1])
plans={}
for line in Path('/tmp/fixed9303-mpoff-plans.jsonl').read_text().splitlines():
 r=json.loads(line)
 plans[tuple(int(i) for i in r['ids'])]={int(i):tuple(p) for i,p in r['final'].items()}
rows=[]
for d in sorted(root.glob('ds_*')):
 wp=d/'workload.json'; pp=d/'placements'/'placements.jsonl'
 if not pp.exists(): continue
 ids=[int(i) for i in json.loads(wp.read_text())['trace_task_ids']]
 desired={str(i):list(plans[tuple(sorted(ids))][tid]) for i,tid in enumerate(ids)}
 sweep=[json.loads(line) for line in pp.read_text().splitlines()]
 found=[p for p in sweep if p['placement_plan']==desired]
 if len(found)!=1: raise RuntimeError(f'{d}: expected one baseline plan, got {len(found)}')
 base=found[0]['rtt']; best=min(p['rtt'] for p in sweep)
 row={'dataset':d.name,'snapshot':json.loads((d/'warm_snapshot.json').read_text())['provenance']['snapshot_id'], 'plans':len(sweep),'baseline':base,'best':best,'headroom_pct':100*(base-best)/base}
 rows.append(row)
 print(row)
print('n',len(rows),'median_headroom_pct',statistics.median(r['headroom_pct'] for r in rows) if rows else None)
