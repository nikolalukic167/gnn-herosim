#!/usr/bin/env python3
"""Frozen 128-pair exact valley screen on previously unscored pair moves on captured groups."""
import argparse
import hashlib
import json
import math
import os
import statistics
import sys
from pathlib import Path

ROOT = Path('/tmp/herosim_peer_coreonly')
sys.path[:0] = [str(ROOT), '/tmp']
from scripts_cosim.important.generate_sampled_slate_snapshots import (
    CosimOracleContext, group_events, group_peer_exchange, score_plan,
    snapshot_tasks, validate_snapshot_infrastructure,
)
from peer_coreonly_move_oracle import candidate_lookup, load_lines, plan_dict, plan_key, proxy, trace_plan, sha

SEEDS = (9801, 9803, 9804, 9806)
GROUPS = range(4, 16)
WORKLOAD = Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json')
MANIFEST = Path('/tmp/fourtype-train-capture-manifest.json')
PARENT = Path('/tmp/peer-coreonly-move-oracle-full.json')
CAP = 128
EPS = 1e-8


def pair_pool(base_key, tasks, pairs):
    choices = [sorted({(int(c['node_id']), int(c['platform_id'])) for c in task['candidates']}) for task in tasks]
    seen = {base_key}
    pool = []
    eligible = 0
    for a, b, payload in sorted(((int(a), int(b), float(w)) for a, b, w in pairs), key=lambda x: (-x[2], x[0], x[1])):
        common = [(ca, cb) for ca in choices[a] for cb in choices[b] if ca[0] == cb[0]]
        for ca, cb in common:
            if ca == base_key[a] or cb == base_key[b]:
                continue
            eligible += 1
            key = list(base_key)
            key[a], key[b] = ca, cb
            key = tuple(key)
            if key in seen:
                continue
            seen.add(key)
            if len(pool) < CAP:
                pool.append((key, a, b, payload))
    return pool, eligible


def digest(key):
    return hashlib.sha256(json.dumps(key).encode()).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if args.out.exists():
        raise FileExistsError(args.out)
    required = ('HEROSIM_PEER_EXCHANGE', 'HEROSIM_PEER_FABRIC', 'HEROSIM_PEER_PREFETCH',
                'HEROSIM_PEER_PREFETCH_CORE_ONLY', 'HEROSIM_PEER_PREFETCH_PIPES')
    if any(os.environ.get(key) != '1' for key in required):
        raise RuntimeError('finite core-only prefetch flags required')
    manifest = json.loads(MANIFEST.read_text())
    parent = json.loads(PARENT.read_text())
    if sha(WORKLOAD) != manifest['workload']['sha256'] or len(parent['results']) != 64:
        raise RuntimeError('frozen parent input mismatch')
    existing = {(row['seed'], row['snapshot_id']): row for row in parent['results']}
    workload = json.loads(WORKLOAD.read_text())
    out = {'contract': 'g32_coordinated_valley_s0_v1', 'script_sha256': sha(__file__),
           'manifest_sha256': sha(MANIFEST), 'parent_sha256': sha(PARENT),
           'workload_sha256': sha(WORKLOAD), 'groups': list(GROUPS), 'seeds': SEEDS, 'results': []}
    for seed in SEEDS:
        source = manifest['seeds'][str(seed)]['arms']
        paths = [source['hand']['paths']['-snapshots.jsonl'],
                 source['hand']['paths']['-plans.jsonl'],
                 source['mpoff']['paths']['-plans.jsonl']]
        for record in paths:
            if sha(record['path']) != record['sha256']:
                raise RuntimeError('captured input digest mismatch')
        cfg = Path(f'/tmp/fixed-g32-config-{seed}.json')
        if sha(cfg) != manifest['seeds'][str(seed)]['config_sha256']:
            raise RuntimeError('config digest mismatch')
        snaps, hand, mpoff = (load_lines(record['path'])[4:16] for record in paths)
        ctx = CosimOracleContext(cfg, ROOT/'data/nofs-ids', seed)
        for snap, htrace, mtrace in zip(snaps, hand, mpoff):
            tasks = snapshot_tasks(snap, None)
            validate_snapshot_infrastructure(ctx, snap)
            bases = {'hand': trace_plan(htrace, tasks), 'mpoff': trace_plan(mtrace, tasks)}
            prior = existing[(seed, snap['snapshot_id'])]
            source_arm = min(bases, key=lambda arm: (prior[arm+'_baseline_rtt'], arm))
            base_key = plan_key(bases[source_arm])
            baseline = prior[source_arm+'_baseline_rtt']
            pairs = group_peer_exchange(snap, workload)
            events = group_events(snap, workload)
            pool, eligible = pair_pool(base_key, tasks, pairs)
            lookup = candidate_lookup(tasks)
            network = {n['node_name']: n.get('network_map') or {} for n in ctx._base_infrastructure['nodes']}
            scores = {base_key: baseline}
            def exact(key):
                if key not in scores:
                    value = float(score_plan(ctx, snap, tasks, plan_dict(key), pairs, events))
                    if not math.isfinite(value):
                        raise ValueError('nonfinite exact score')
                    scores[key] = value
                return scores[key]
            rows = []
            for key, a, b, payload in pool:
                first = list(base_key); first[a] = key[a]; first = tuple(first)
                second = list(base_key); second[b] = key[b]; second = tuple(second)
                first_rtt, second_rtt, joint_rtt = exact(first), exact(second), exact(key)
                valley = first_rtt > baseline + EPS and second_rtt > baseline + EPS and joint_rtt < baseline - EPS
                material_valley = first_rtt >= baseline*1.005 and second_rtt >= baseline*1.005 and joint_rtt <= baseline*0.98
                rows.append({'placement_sha256': digest(key), 'a': a, 'b': b, 'payload': payload,
                             'first_rtt': first_rtt, 'second_rtt': second_rtt, 'joint_rtt': joint_rtt,
                             'first_delta': first_rtt-baseline, 'second_delta': second_rtt-baseline,
                             'joint_gain': baseline-joint_rtt, 'strict_valley': valley,
                             'material_valley': material_valley,
                             'simple_proxy': proxy(key, lookup, pairs, network)})
            ranked = sorted(range(len(rows)), key=lambda i: (rows[i]['simple_proxy'], rows[i]['placement_sha256']))[:16]
            all_oracle = min([baseline]+[row['joint_rtt'] for row in rows])
            valley_oracle = min([baseline]+[row['joint_rtt'] for row in rows if row['strict_valley']])
            material_oracle = min([baseline]+[row['joint_rtt'] for row in rows if row['material_valley']])
            hand_rtt = min([baseline]+[rows[i]['joint_rtt'] for i in ranked])
            rec = {'seed': seed, 'snapshot_id': snap['snapshot_id'], 'source_arm': source_arm,
                   'baseline_rtt': baseline, 'all_pair_oracle_rtt': all_oracle,
                   'valley_oracle_rtt': valley_oracle, 'material_valley_oracle_rtt': material_oracle,
                   'simple_hand_rtt': hand_rtt,
                   'eligible_with_duplicates': eligible, 'retained': len(pool),
                   'unique_exact_evaluations': len(scores), 'valley_count': sum(row['strict_valley'] for row in rows),
                   'material_valley_count': sum(row['material_valley'] for row in rows),
                   'simple_selected_rows': ranked, 'rows': rows}
            out['results'].append(rec)
            args.out.write_text(json.dumps(out, separators=(',', ':')))
            print(seed, snap['snapshot_id'], 'pool', len(pool), 'valleys', rec['valley_count'],
                  'material', rec['material_valley_count'],
                  'baseline', round(baseline, 3), 'valley', round(valley_oracle, 3),
                  'all', round(all_oracle, 3), flush=True)
    for seed in SEEDS:
        rows = [row for row in out['results'] if row['seed'] == seed]
        base = sum(row['baseline_rtt'] for row in rows)
        valley = sum(row['valley_oracle_rtt'] for row in rows)
        material = sum(row['material_valley_oracle_rtt'] for row in rows)
        all_pair = sum(row['all_pair_oracle_rtt'] for row in rows)
        hand = sum(row['simple_hand_rtt'] for row in rows)
        print('SUMMARY', seed, 'valley_gain_pct', 100*(base-valley)/base,
              'material_valley_gain_pct', 100*(base-material)/base,
              'all_pair_gain_pct', 100*(base-all_pair)/base,
              'simple_capture', (base-hand)/(base-all_pair) if base>all_pair else None,
              'valley_groups', sum(row['valley_count']>0 for row in rows),
              'material_groups', sum(row['material_valley_count']>0 for row in rows), flush=True)
    print('TOTAL_EXACT', sum(row['unique_exact_evaluations'] for row in out['results']), flush=True)


if __name__ == '__main__':
    main()
