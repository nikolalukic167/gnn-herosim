#!/usr/bin/env bash
set -euo pipefail
kind="$1"
arm="$2"
seed="${3:-9303}"
case "$kind" in bridge|bridge_shuffled) ;; *) exit 2;; esac
case "$arm" in
 gnn) policy=gnn_seeded_cd; model=/tmp/jb2-gnnedge0-seed1.pt; mp=0;;
 mpoff) policy=gnn_seeded_cd; model=/tmp/jb2-mpoff-seed1.pt; mp=1;;
 hand) policy=peer_greedy_network_cd; model=/tmp/jb2-mpoff-seed1.pt; mp=1;;
 *) exit 2;;
esac
export PIPENV_IGNORE_VIRTUALENVS=1 VIRTUAL_ENV= PYTHONPATH=/root/projects/my-herosim
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONHASHSEED=0
export HEROSIM_PG_EXCHANGE_SCALE=2 HEROSIM_PG_CD_PASSES=6 HEROSIM_PEER_EXCHANGE=1
export HEROSIM_SERVER_ONLY_REPLICAS=1 HEROSIM_WARMTH_PHYSICS=node_disk_v2
export GNN_MODEL_PATH="$model" GNN_DECODE_MODE=masked_topo GNN_QUEUE_NORM_MODE=scheduler_adaptive
export GNN_BATCH_BY_PEER_GROUP=1 GNN_BATCH_SIZE=32 GNN_PREFIX_ALPHA_KEY=inf
export GNN_DISABLE_MESSAGE_PASSING="$mp" GNN_MP_PLATFORM_EDGES_OFF=0
export PARTIAL_STATE_CONTRACT=partial_state_v3 PARTIAL_STATE_PEER_MASS=1
export INFERENCE_FEATURE_LAYOUT=dim22 TOPOLOGY_FEATURE_CONTRACT=src_index_v0
export QUEUE_FEATURE_CONTRACT=legacy_v0 HEROSIM_GNN_DEVICE=cpu
export FIXED_REPLICA_MANIFEST_PATH="/tmp/fixed-g32-${kind}-${seed}-${arm}-manifest.json"
if [[ "$arm" == mpoff ]]; then
 export LIVE_AUDIT_SNAPSHOT_PATH="/tmp/fixed-g32-${kind}-${seed}-snap.jsonl"
 export LIVE_AUDIT_MAX_SNAPSHOTS=16 LIVE_AUDIT_STRIDE=32
 export LIVE_AUDIT_MIN_BATCH_SIZE=32 LIVE_AUDIT_MIN_CANDIDATES=2
fi
pipenv run python3 /tmp/fixed_g32_runner.py \
 --config "/tmp/fixed-g32-config-${seed}.json" \
 --workload "/tmp/fixed-g32-${kind}-5120.json" \
 --policy "$policy" --queue-length 100 \
 --output "/tmp/fixed-g32-${kind}-${seed}-${arm}.json" \
 > "/tmp/fixed-g32-${kind}-${seed}-${arm}.log" 2>&1
