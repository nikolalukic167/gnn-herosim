#!/usr/bin/env bash
set -euo pipefail
kind="$1"
seed="$2"
arm="${SELECTOR_ARM:-selector}"
scale=4
model=/tmp/jb2-gnnedge0-seed1.pt
mp=0
export PIPENV_IGNORE_VIRTUALENVS=1 VIRTUAL_ENV= PYTHONPATH=/root/projects/my-herosim
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONHASHSEED=0
export HEROSIM_PG_EXCHANGE_SCALE="$scale" HEROSIM_PG_CD_PASSES=6 HEROSIM_PEER_EXCHANGE=1
export HEROSIM_SERVER_ONLY_REPLICAS=1 HEROSIM_WARMTH_PHYSICS=node_disk_v2
export GNN_MODEL_PATH="$model" GNN_DECODE_MODE=masked_topo GNN_QUEUE_NORM_MODE=scheduler_adaptive
export GNN_BATCH_BY_PEER_GROUP=1 GNN_BATCH_SIZE=32 GNN_PREFIX_ALPHA_KEY=inf
export GNN_DISABLE_MESSAGE_PASSING="$mp" GNN_MP_PLATFORM_EDGES_OFF=0
export PARTIAL_STATE_CONTRACT=partial_state_v3 PARTIAL_STATE_PEER_MASS=1
export INFERENCE_FEATURE_LAYOUT=dim22 TOPOLOGY_FEATURE_CONTRACT=src_index_v0
export QUEUE_FEATURE_CONTRACT=legacy_v0 HEROSIM_GNN_DEVICE=cpu
export FIXED_REPLICA_MANIFEST_PATH="/tmp/fixed-g32-${kind}-${seed}-${arm}-s${scale}-manifest.json"
export SELECTOR_TRACE_PATH="/tmp/fixed-g32-${kind}-${seed}-${arm}-s${scale}-plans.jsonl"
pipenv run python3 /tmp/fixed_g32_selector_runner.py \
 --config "/tmp/fixed-g32-config-${seed}.json" \
 --workload "/tmp/fixed-g32-${kind}-5120.json" \
 --policy gnn_seeded_cd --queue-length 100 \
 --output "/tmp/fixed-g32-${kind}-${seed}-${arm}-s${scale}.json" \
 > "/tmp/fixed-g32-${kind}-${seed}-${arm}-s${scale}.log" 2>&1
