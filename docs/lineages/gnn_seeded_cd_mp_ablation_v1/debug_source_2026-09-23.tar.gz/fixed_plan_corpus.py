import json
import os
from pathlib import Path
from scripts_cosim import make_warm_corpus as corpus

plans = {}
for line in Path(os.environ['FIXED_PLAN_TRACE_PATH']).read_text().splitlines():
    record = json.loads(line)
    ids = [int(i) for i in record['ids']]
    plans[tuple(ids)] = {int(i): tuple(p) for i, p in record['final'].items()}

def fixed_plan_keys(snapshot):
    ids = tuple(int(task['task_id']) for task in snapshot['tasks'])
    if ids not in plans:
        raise RuntimeError(f'fixed plan missing for snapshot task ids {ids}')
    forced = {}
    for task in snapshot['tasks']:
        tid = int(task['task_id'])
        pair = plans[ids][tid]
        matches = [c for c in task['candidates']
                   if (int(c['node_id']), int(c['platform_id'])) == pair]
        if len(matches) != 1:
            raise RuntimeError(f'task {tid} plan {pair} matched {len(matches)} candidates')
        forced.setdefault(str(task['task_type']), set()).add(str(matches[0]['queue_key']))
    return forced

corpus.reactive_plan_keys = fixed_plan_keys
raise SystemExit(corpus.main())
