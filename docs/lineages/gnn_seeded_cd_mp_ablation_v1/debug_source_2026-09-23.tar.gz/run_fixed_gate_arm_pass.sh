#!/usr/bin/env bash
set -euo pipefail
cell="$1"
arm="$2"
config="$3"
output_dir="$4"
case "$arm" in gnn|mpoff) policy=gnn_seeded_cd;; hand) policy=peer_greedy_network_cd;; *) exit 2;; esac
mkdir -p "$output_dir"
export PIPENV_IGNORE_VIRTUALENVS=1 VIRTUAL_ENV= PYTHONPATH=/root/projects/my-herosim
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONHASHSEED=0
export HEROSIM_PG_EXCHANGE_SCALE=2 HEROSIM_PG_CD_PASSES="${CD_PASSES_OVERRIDE:-6}" HEROSIM_PEER_EXCHANGE=1
export HEROSIM_SERVER_ONLY_REPLICAS=1 HEROSIM_WARMTH_PHYSICS=node_disk_v2
export GNN_MODEL_PATH="${MODEL_PATH_OVERRIDE:-/tmp/jb2-gnnedge0-seed1.pt}" GNN_DECODE_MODE=masked_topo
export GNN_QUEUE_NORM_MODE=scheduler_adaptive GNN_BATCH_BY_PEER_GROUP=1 GNN_PREFIX_ALPHA_KEY=inf
export GNN_DISABLE_MESSAGE_PASSING="${MP_DISABLE_OVERRIDE:-0}" GNN_MP_PLATFORM_EDGES_OFF=0
export PARTIAL_STATE_CONTRACT=partial_state_v3 PARTIAL_STATE_PEER_MASS=1
export INFERENCE_FEATURE_LAYOUT=dim22 TOPOLOGY_FEATURE_CONTRACT=src_index_v0
export QUEUE_FEATURE_CONTRACT=legacy_v0 HEROSIM_GNN_DEVICE=cpu
export FIXED_REPLICA_MANIFEST_PATH="$output_dir/${cell}-${arm}-manifest.json"
pipenv run python3 scripts_cosim/important/gnn_seeded_cd_fixed_v1.py \
  --config "$config" --workload /tmp/jb2-burst-f4000-n50000.json \
  --policy "$policy" --queue-length 100 \
  --output "$output_dir/${cell}-${arm}.json" \
  > "$output_dir/${cell}-${arm}.log" 2>&1
