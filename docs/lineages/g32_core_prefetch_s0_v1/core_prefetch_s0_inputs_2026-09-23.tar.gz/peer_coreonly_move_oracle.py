#!/usr/bin/env python3
"""Exact bounded placement-move S0 on frozen four-type training captures."""
import argparse
import hashlib
import json
import math
import os
import statistics
import sys
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path('/tmp/herosim_peer_coreonly')
sys.path.insert(0, str(ROOT))
from scripts_cosim.important.generate_sampled_slate_snapshots import (
    CosimOracleContext, group_events, group_peer_exchange, score_plan,
    snapshot_tasks, validate_snapshot_infrastructure,
)

SEEDS = (9801, 9803, 9804, 9806)
WORKLOAD = Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json')
MANIFEST = Path('/tmp/fourtype-train-capture-manifest.json')
PROXY_CONTRACT = {
    'version': 'fixed_platform_count_peer_v1',
    'local_fields': ('execution_time', 'communications_time', 'network_latency', 'queue_drain_seconds', 'cold_start_time'),
    'peer_bandwidth_bytes_per_second': 100 * 1024 * 1024,
    'peer_latency_weight': 1.0,
    'platform_squared_load_divisor': 32.0,
    'rank_tie_break': 'full placement tuple lexicographic',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_lines(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def plan_key(plan):
    return tuple(plan[i] for i in range(32))


def plan_dict(key):
    return dict(enumerate(key))


def candidate_lookup(tasks):
    return [{(int(c['node_id']), int(c['platform_id'])): c for c in task['candidates']} for task in tasks]


def local_cost(candidate):
    return sum(float(candidate.get(field, 0) or 0) for field in PROXY_CONTRACT['local_fields'])


def proxy(key, lookup, pairs, network):
    local = 0.0
    load = defaultdict(float)
    for i, placement in enumerate(key):
        candidate = lookup[i][placement]
        local += local_cost(candidate)
        load[placement] += float(candidate['execution_time']) + float(candidate['communications_time'])
    peer = 0.0
    for a, b, payload in pairs:
        a, b, payload = int(a), int(b), float(payload)
        if key[a][0] == key[b][0]:
            continue
        ca, cb = lookup[a][key[a]], lookup[b][key[b]]
        name_a, name_b = ca['node_name'], cb['node_name']
        def latency(x, y):
            entry = network[x][y]
            return float(entry.get('latency', 0) if isinstance(entry, dict) else entry)
        transfer = payload / PROXY_CONTRACT['peer_bandwidth_bytes_per_second']
        peer += 2 * transfer + latency(name_a, name_b) + latency(name_b, name_a)
        load[key[a]] += transfer
        load[key[b]] += transfer
    return local + peer + sum(x*x for x in load.values()) / PROXY_CONTRACT['platform_squared_load_divisor']


def build_pool(tasks, bases, cap=128):
    choices = [sorted({(int(c['node_id']), int(c['platform_id'])) for c in task['candidates']}) for task in tasks]
    baseline = {plan_key(plan) for plan in bases.values()}
    seen = set(baseline)
    pool = []
    total_singles = 0
    total_swaps = 0
    for source, base in bases.items():
        key = plan_key(base)
        for i in range(32):
            for target in choices[i]:
                if target == key[i]:
                    continue
                moved = key[:i] + (target,) + key[i+1:]
                total_singles += 1
                if moved not in seen:
                    seen.add(moved)
                    if len(pool) < cap:
                        pool.append((moved, f'single:{source}:{i}:{target[0]}:{target[1]}'))
    singles_retained = len(pool)
    if len(pool) < cap:
        for source, base in bases.items():
            key = plan_key(base)
            for i in range(32):
                for j in range(i+1, 32):
                    if key[i] == key[j] or key[j] not in choices[i] or key[i] not in choices[j]:
                        continue
                    swapped = list(key)
                    swapped[i], swapped[j] = swapped[j], swapped[i]
                    swapped = tuple(swapped)
                    total_swaps += 1
                    if swapped not in seen:
                        seen.add(swapped)
                        if len(pool) < cap:
                            pool.append((swapped, f'swap:{source}:{i}:{j}'))
    return pool, {'enumerated_singles_with_duplicates': total_singles,
                  'unique_singles': len(seen - baseline) if singles_retained == cap else singles_retained,
                  'retained_singles': singles_retained,
                  'enumerated_swaps_with_duplicates': total_swaps,
                  'retained_swaps': len(pool) - singles_retained,
                  'cap': cap, 'retained': len(pool),
                  'cap_hit': len(pool) == cap}


def trace_plan(trace, tasks):
    ids = [int(t['task_id']) for t in tasks]
    if ids != list(trace['ids']):
        raise ValueError('trace task IDs mismatch')
    return {i: tuple(map(int, trace['final'][str(task_id)])) for i, task_id in enumerate(ids)}


def group(ctx, snap, hand_trace, mpoff_trace, workload):
    start = time.monotonic()
    tasks = snapshot_tasks(snap, None)
    if len(tasks) != 32:
        raise ValueError('group size mismatch')
    validate_snapshot_infrastructure(ctx, snap)
    bases = {'hand': trace_plan(hand_trace, tasks), 'mpoff': trace_plan(mpoff_trace, tasks)}
    for name, plan in bases.items():
        if not ctx.validate_placement_plan(tasks, plan):
            raise ValueError(f'{name} infeasible on common state')
    pairs = group_peer_exchange(snap, workload)
    events = group_events(snap, workload)
    lookup = candidate_lookup(tasks)
    network = {n['node_name']: n.get('network_map') or {} for n in ctx._base_infrastructure['nodes']}
    pool, coverage = build_pool(tasks, bases)
    hand_ranked = sorted(pool, key=lambda row: (proxy(row[0], lookup, pairs, network), row[0]))[:16]
    hand_keys = {row[0] for row in hand_ranked}
    scores = {}
    for plan in bases.values():
        key = plan_key(plan)
        if key not in scores:
            scores[key] = float(score_plan(ctx, snap, tasks, plan, pairs, events))
    for key, _ in pool:
        score = float(score_plan(ctx, snap, tasks, plan_dict(key), pairs, events))
        if not math.isfinite(score):
            raise ValueError('nonfinite exact RTT')
        scores[key] = score
    baseline = min(scores[plan_key(plan)] for plan in bases.values())
    oracle = min(baseline, *(scores[key] for key, _ in pool))
    hand = min(baseline, *(scores[key] for key in hand_keys))
    if oracle > hand + 1e-8 or hand > baseline + 1e-8:
        raise AssertionError('nested search budget ordering failed')
    rows = [{'source': source, 'placement_sha256': hashlib.sha256(json.dumps(key).encode()).hexdigest(),
             'rtt': scores[key], 'proxy': proxy(key, lookup, pairs, network),
             'hand_selected': key in hand_keys}
            for key, source in pool]
    return {'snapshot_id': snap['snapshot_id'], 'task_ids': [int(t['task_id']) for t in tasks],
            'baseline_rtt': baseline, 'oracle_rtt': oracle, 'hand_rtt': hand,
            'hand_baseline_rtt': scores[plan_key(bases['hand'])],
            'mpoff_baseline_rtt': scores[plan_key(bases['mpoff'])],
            'baseline_unique_evaluations': len({plan_key(plan) for plan in bases.values()}),
            'oracle_additional_evaluations': len(pool), 'hand_additional_evaluations': len(hand_keys),
            'pool': coverage, 'peer_pairs': len(pairs),
            'best_candidate_sources': [source for key, source in pool if abs(scores[key] - oracle) < 1e-8],
            'rows': rows, 'elapsed_seconds': time.monotonic()-start}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--groups', type=int, default=16)
    ap.add_argument('--seeds', type=int, nargs='+', default=list(SEEDS))
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if any(os.environ.get(k) != '1' for k in ('HEROSIM_PEER_EXCHANGE','HEROSIM_PEER_FABRIC','HEROSIM_PEER_PREFETCH','HEROSIM_PEER_PREFETCH_CORE_ONLY','HEROSIM_PEER_PREFETCH_PIPES')):
        raise RuntimeError('finite core-only prefetch flags required')
    if args.out.exists():
        raise FileExistsError(args.out)
    if args.groups < 1 or args.groups > 16 or not set(args.seeds) <= set(SEEDS):
        raise ValueError('invalid groups or seeds')
    manifest = json.loads(MANIFEST.read_text())
    if sha(WORKLOAD) != manifest['workload']['sha256']:
        raise RuntimeError('workload digest mismatch')
    workload = json.loads(WORKLOAD.read_text())
    output = {'contract': 'g32_core_prefetch_move_oracle_s0_v1', 'script_sha256': sha(__file__),
              'proxy_contract': PROXY_CONTRACT, 'manifest_sha256': sha(MANIFEST),
              'workload_sha256': sha(WORKLOAD), 'groups_per_seed': args.groups,
              'seeds': args.seeds, 'results': []}
    for seed in args.seeds:
        source = manifest['seeds'][str(seed)]['arms']
        paths = [source['hand']['paths']['-snapshots.jsonl'],
                 source['hand']['paths']['-plans.jsonl'],
                 source['mpoff']['paths']['-plans.jsonl']]
        for record in paths:
            if sha(record['path']) != record['sha256']:
                raise RuntimeError(f"input digest mismatch {record['path']}")
        cfg = Path(f'/tmp/fixed-g32-config-{seed}.json')
        if sha(cfg) != manifest['seeds'][str(seed)]['config_sha256']:
            raise RuntimeError('config digest mismatch')
        snapshots, hand_traces, mpoff_traces = (load_lines(record['path'])[:args.groups] for record in paths)
        if any(len(rows) != args.groups for rows in (snapshots, hand_traces, mpoff_traces)):
            raise RuntimeError('missing source groups')
        ctx = CosimOracleContext(cfg, ROOT/'data/nofs-ids', seed)
        for idx, (snap, hand_trace, mpoff_trace) in enumerate(zip(snapshots, hand_traces, mpoff_traces)):
            result = group(ctx, snap, hand_trace, mpoff_trace, workload)
            result['seed'] = seed
            output['results'].append(result)
            args.out.write_text(json.dumps(output, separators=(',', ':')))
            print(f"seed={seed} group={idx} base={result['baseline_rtt']:.3f} "
                  f"oracle={result['oracle_rtt']:.3f} hand={result['hand_rtt']:.3f} "
                  f"pool={result['pool']['retained']} sec={result['elapsed_seconds']:.2f}", flush=True)
    for seed in args.seeds:
        rows = [row for row in output['results'] if row['seed'] == seed]
        base, oracle, hand = (sum(row[field] for row in rows) for field in
                              ('baseline_rtt', 'oracle_rtt', 'hand_rtt'))
        gain = 100*(base-oracle)/base
        capture = (base-hand)/(base-oracle) if base > oracle else None
        print(f'SUMMARY seed={seed} base={base:.6f} oracle={oracle:.6f} hand={hand:.6f} '
              f'gain_pct={gain:.6f} capture={capture}', flush=True)
    if len(args.seeds) == 4:
        gains = []
        for seed in args.seeds:
            rows = [row for row in output['results'] if row['seed'] == seed]
            base = sum(row['baseline_rtt'] for row in rows)
            oracle = sum(row['oracle_rtt'] for row in rows)
            gains.append(100*(base-oracle)/base)
        print(f'MEDIAN_TOPOLOGY_GAIN_PCT={statistics.median(gains):.6f}', flush=True)


if __name__ == '__main__':
    main()
