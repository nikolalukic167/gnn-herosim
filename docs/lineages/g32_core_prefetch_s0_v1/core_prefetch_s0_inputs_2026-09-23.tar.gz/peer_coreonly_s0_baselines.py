#!/usr/bin/env python3
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0,'/tmp/herosim_peer_coreonly')
from scripts_cosim.important.generate_sampled_slate_snapshots import (
    CosimOracleContext, full_result, group_events, group_peer_exchange,
    snapshot_tasks, validate_snapshot_infrastructure,
)

if os.environ.get('HEROSIM_PEER_EXCHANGE')!='1' or os.environ.get('HEROSIM_PEER_FABRIC')!='1' or os.environ.get('HEROSIM_PEER_PREFETCH')!='1' or os.environ.get('HEROSIM_PEER_PREFETCH_CORE_ONLY')!='1':
    raise RuntimeError('peer prefetch physics flags must be on')
SEEDS=(9801,9803,9804,9806)
WORKLOAD=Path('/tmp/fixed-g32-fourtype-lowpayload-5120.json')
OUT=Path('/tmp/peer-coreonly-s0-baselines.json')
if OUT.exists():raise FileExistsError(OUT)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
workload=json.loads(WORKLOAD.read_text())
output={'contract':'g32_core_prefetch_s0_baselines_v1','source_hashes':{
    str(p):sha(p) for p in [WORKLOAD,Path(__file__),Path('/tmp/herosim_peer_coreonly/src/placement/infrastructure.py'),Path('/tmp/herosim_peer_coreonly/src/placement/orchestrator.py'),Path('/tmp/herosim_peer_coreonly/src/placement/scheduler.py')]},'rows':[]}
for seed in SEEDS:
    ctx=CosimOracleContext(Path(f'/tmp/fixed-g32-config-{seed}.json'),Path('/tmp/herosim_peer_coreonly/data/nofs-ids'),seed)
    snapshots=[json.loads(x) for x in Path(f'/tmp/fourtype-train-{seed}-hand-snapshots.jsonl').read_text().splitlines()[:16]]
    traces={arm:[json.loads(x) for x in Path(f'/tmp/fourtype-train-{seed}-{arm}-plans.jsonl').read_text().splitlines()[:16]] for arm in ('hand','mpoff')}
    for group,snap in enumerate(snapshots):
        tasks=snapshot_tasks(snap,None)
        validate_snapshot_infrastructure(ctx,snap)
        pairs=group_peer_exchange(snap,workload)
        events=group_events(snap,workload)
        ids=[int(t['task_id']) for t in tasks]
        for arm in ('hand','mpoff'):
            trace=traces[arm][group]
            if ids!=list(trace['ids']):raise ValueError('task ID mismatch')
            plan={i:tuple(map(int,trace['final'][str(task_id)])) for i,task_id in enumerate(ids)}
            if not ctx.validate_placement_plan(tasks,plan):raise ValueError('infeasible captured plan')
            for mode,pipes in [('infinite','0'),('finite','1')]:
                os.environ['HEROSIM_PEER_PREFETCH_PIPES']=pipes
                result=full_result(ctx,snap,tasks,plan,pairs,events)
                stats=result['stats']
                if result.get('status')!='success' or stats['num_tasks']!=32:
                    raise RuntimeError('invalid exact result')
                record={'seed':seed,'group':group,'arm':arm,'mode':mode,'rtt':stats['total_rtt'],'tasks':stats['num_tasks'],
                    'core_wait':stats['peerFabricCoreWaitTotal'],'peer_wait':stats['peerFabricWaitTotal'],
                    'peer_transfer':stats['peerFabricTransferTotal'],'all_link_wait':stats['totalLinkWaitTime'],
                    'peer_exchange':stats['totalPeerExchangeTime']}
                output['rows'].append(record)
                OUT.write_text(json.dumps(output,separators=(',',':')))
                print(seed,group,arm,mode,round(record['rtt'],3),round(record['core_wait']/record['rtt']*100,3),flush=True)
